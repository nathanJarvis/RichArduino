/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//warehouse2.seasad.wustl.edu/home/nathan.jarvis/CSE462/IO/richArduinoRev0/conbit.vhd";



static void work_a_2851529566_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned int t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    unsigned char t25;
    int t26;
    unsigned int t27;
    unsigned int t28;

LAB0:    xsi_set_current_line(21, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = (31 - 2);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4828);
    t8 = 1;
    if (3U == 3U)
        goto LAB5;

LAB6:    t8 = 0;

LAB7:    if (t8 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = (31 - 2);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4831);
    t17 = 1;
    if (3U == 3U)
        goto LAB16;

LAB17:    t17 = 0;

LAB18:    if (t17 == 1)
        goto LAB13;

LAB14:    t8 = (unsigned char)0;

LAB15:    if (t8 != 0)
        goto LAB11;

LAB12:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = (31 - 2);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4866);
    t17 = 1;
    if (3U == 3U)
        goto LAB33;

LAB34:    t17 = 0;

LAB35:    if (t17 == 1)
        goto LAB30;

LAB31:    t8 = (unsigned char)0;

LAB32:    if (t8 != 0)
        goto LAB28;

LAB29:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = (31 - 2);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4901);
    t17 = 1;
    if (3U == 3U)
        goto LAB50;

LAB51:    t17 = 0;

LAB52:    if (t17 == 1)
        goto LAB47;

LAB48:    t8 = (unsigned char)0;

LAB49:    if (t8 != 0)
        goto LAB45;

LAB46:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = (31 - 2);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 4904);
    t17 = 1;
    if (3U == 3U)
        goto LAB61;

LAB62:    t17 = 0;

LAB63:    if (t17 == 1)
        goto LAB58;

LAB59:    t8 = (unsigned char)0;

LAB60:    if (t8 != 0)
        goto LAB56;

LAB57:    xsi_set_current_line(32, ng0);
    t1 = (t0 + 2912);
    t2 = (t1 + 56U);
    t6 = *((char **)t2);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB3:    t1 = (t0 + 2832);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(22, ng0);
    t12 = (t0 + 2912);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t12);
    goto LAB3;

LAB5:    t9 = 0;

LAB8:    if (t9 < 3U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t10 = (t1 + t9);
    t11 = (t6 + t9);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB6;

LAB10:    t9 = (t9 + 1);
    goto LAB8;

LAB11:    xsi_set_current_line(24, ng0);
    t20 = (t0 + 2912);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t20);
    goto LAB3;

LAB13:    t12 = (t0 + 1032U);
    t13 = *((char **)t12);
    t12 = (t0 + 4834);
    t18 = 1;
    if (32U == 32U)
        goto LAB22;

LAB23:    t18 = 0;

LAB24:    t8 = t18;
    goto LAB15;

LAB16:    t9 = 0;

LAB19:    if (t9 < 3U)
        goto LAB20;
    else
        goto LAB18;

LAB20:    t10 = (t1 + t9);
    t11 = (t6 + t9);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB17;

LAB21:    t9 = (t9 + 1);
    goto LAB19;

LAB22:    t19 = 0;

LAB25:    if (t19 < 32U)
        goto LAB26;
    else
        goto LAB24;

LAB26:    t15 = (t13 + t19);
    t16 = (t12 + t19);
    if (*((unsigned char *)t15) != *((unsigned char *)t16))
        goto LAB23;

LAB27:    t19 = (t19 + 1);
    goto LAB25;

LAB28:    xsi_set_current_line(26, ng0);
    t20 = (t0 + 2912);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t20);
    goto LAB3;

LAB30:    t12 = (t0 + 1032U);
    t13 = *((char **)t12);
    t12 = (t0 + 4869);
    t18 = 1;
    if (32U == 32U)
        goto LAB39;

LAB40:    t18 = 0;

LAB41:    t25 = (!(t18));
    t8 = t25;
    goto LAB32;

LAB33:    t9 = 0;

LAB36:    if (t9 < 3U)
        goto LAB37;
    else
        goto LAB35;

LAB37:    t10 = (t1 + t9);
    t11 = (t6 + t9);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB34;

LAB38:    t9 = (t9 + 1);
    goto LAB36;

LAB39:    t19 = 0;

LAB42:    if (t19 < 32U)
        goto LAB43;
    else
        goto LAB41;

LAB43:    t15 = (t13 + t19);
    t16 = (t12 + t19);
    if (*((unsigned char *)t15) != *((unsigned char *)t16))
        goto LAB40;

LAB44:    t19 = (t19 + 1);
    goto LAB42;

LAB45:    xsi_set_current_line(28, ng0);
    t14 = (t0 + 2912);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t20 = (t16 + 56U);
    t21 = *((char **)t20);
    *((unsigned char *)t21) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t14);
    goto LAB3;

LAB47:    t12 = (t0 + 1032U);
    t13 = *((char **)t12);
    t26 = (31 - 31);
    t19 = (t26 * -1);
    t27 = (1U * t19);
    t28 = (0 + t27);
    t12 = (t13 + t28);
    t18 = *((unsigned char *)t12);
    t25 = (t18 == (unsigned char)2);
    t8 = t25;
    goto LAB49;

LAB50:    t9 = 0;

LAB53:    if (t9 < 3U)
        goto LAB54;
    else
        goto LAB52;

LAB54:    t10 = (t1 + t9);
    t11 = (t6 + t9);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB51;

LAB55:    t9 = (t9 + 1);
    goto LAB53;

LAB56:    xsi_set_current_line(30, ng0);
    t14 = (t0 + 2912);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t20 = (t16 + 56U);
    t21 = *((char **)t20);
    *((unsigned char *)t21) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t14);
    goto LAB3;

LAB58:    t12 = (t0 + 1032U);
    t13 = *((char **)t12);
    t26 = (31 - 31);
    t19 = (t26 * -1);
    t27 = (1U * t19);
    t28 = (0 + t27);
    t12 = (t13 + t28);
    t18 = *((unsigned char *)t12);
    t25 = (t18 == (unsigned char)3);
    t8 = t25;
    goto LAB60;

LAB61:    t9 = 0;

LAB64:    if (t9 < 3U)
        goto LAB65;
    else
        goto LAB63;

LAB65:    t10 = (t1 + t9);
    t11 = (t6 + t9);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB62;

LAB66:    t9 = (t9 + 1);
    goto LAB64;

}


extern void work_a_2851529566_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2851529566_3212880686_p_0};
	xsi_register_didat("work_a_2851529566_3212880686", "isim/testbenchI2C_isim_beh.exe.sim/work/a_2851529566_3212880686.didat");
	xsi_register_executes(pe);
}
