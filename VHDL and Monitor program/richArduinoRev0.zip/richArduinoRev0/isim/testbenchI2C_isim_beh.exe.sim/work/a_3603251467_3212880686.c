/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//warehouse2.seasad.wustl.edu/home/nathan.jarvis/CSE462/IO/richArduinoRev0/shiftcounter.vhd";



static void work_a_3603251467_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(23, ng0);

LAB3:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = (31 - 4);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 3336);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 5U);
    xsi_driver_first_trans_fast(t6);

LAB2:    t11 = (t0 + 3240);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3603251467_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t4;
    unsigned int t5;
    char *t6;
    char *t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    xsi_set_current_line(25, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t1 = (t0 + 5581);
    t4 = 1;
    if (5U == 5U)
        goto LAB5;

LAB6:    t4 = 0;

LAB7:    t8 = (!(t4));
    if (t8 != 0)
        goto LAB3;

LAB4:
LAB11:    t15 = (t0 + 1032U);
    t16 = *((char **)t15);
    t17 = (31 - 4);
    t18 = (t17 * 1U);
    t19 = (0 + t18);
    t15 = (t16 + t19);
    t20 = (t0 + 3400);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t15, 5U);
    xsi_driver_first_trans_fast_port(t20);

LAB2:    t25 = (t0 + 3256);
    *((int *)t25) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 1512U);
    t10 = *((char **)t9);
    t9 = (t0 + 3400);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t10, 5U);
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t5 = 0;

LAB8:    if (t5 < 5U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB6;

LAB10:    t5 = (t5 + 1);
    goto LAB8;

LAB12:    goto LAB2;

}


extern void work_a_3603251467_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3603251467_3212880686_p_0,(void *)work_a_3603251467_3212880686_p_1};
	xsi_register_didat("work_a_3603251467_3212880686", "isim/testbenchI2C_isim_beh.exe.sim/work/a_3603251467_3212880686.didat");
	xsi_register_executes(pe);
}
