/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//warehouse2.seasad.wustl.edu/home/nathan.jarvis/CSE462/IO/richArduinoRev0/ir.vhd";
extern char *IEEE_P_2592010699;



static void work_a_0380725995_3212880686_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;

LAB0:    xsi_set_current_line(26, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 3720);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(27, ng0);
    t7 = (t0 + 1672U);
    t8 = *((char **)t7);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    if (t10 != 0)
        goto LAB8;

LAB10:
LAB9:    goto LAB3;

LAB5:    t2 = (t0 + 1152U);
    t6 = xsi_signal_has_event(t2);
    t1 = t6;
    goto LAB7;

LAB8:    xsi_set_current_line(28, ng0);
    t7 = (t0 + 1032U);
    t11 = *((char **)t7);
    t12 = (31 - 31);
    t13 = (t12 * 1U);
    t14 = (0 + t13);
    t7 = (t11 + t14);
    t15 = (t0 + 3816);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t7, 32U);
    xsi_driver_first_trans_delta(t15, 0U, 32U, 0LL);
    goto LAB9;

}

static void work_a_0380725995_3212880686_p_1(char *t0)
{
    char t19[16];
    char t29[16];
    char t39[16];
    char t49[16];
    char t59[16];
    char t69[16];
    char t79[16];
    char t89[16];
    char t99[16];
    char t107[16];
    char t109[16];
    char t133[16];
    char t140[16];
    char t149[16];
    char t157[16];
    char t159[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned char t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned char t27;
    char *t28;
    char *t30;
    char *t31;
    char *t32;
    int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned char t37;
    char *t38;
    char *t40;
    char *t41;
    char *t42;
    int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned char t47;
    char *t48;
    char *t50;
    char *t51;
    char *t52;
    int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned char t57;
    char *t58;
    char *t60;
    char *t61;
    char *t62;
    int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned char t67;
    char *t68;
    char *t70;
    char *t71;
    char *t72;
    int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned char t77;
    char *t78;
    char *t80;
    char *t81;
    char *t82;
    int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned char t87;
    char *t88;
    char *t90;
    char *t91;
    char *t92;
    int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned char t97;
    char *t98;
    char *t100;
    char *t101;
    char *t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    char *t108;
    char *t110;
    char *t111;
    int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned char t123;
    char *t124;
    char *t125;
    char *t126;
    char *t127;
    int t128;
    unsigned char t129;
    int t130;
    unsigned char t131;
    char *t132;
    char *t134;
    char *t135;
    char *t136;
    int t137;
    unsigned char t138;
    char *t139;
    char *t141;
    char *t142;
    char *t143;
    int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned char t147;
    char *t148;
    char *t150;
    char *t151;
    char *t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    char *t156;
    char *t158;
    char *t160;
    char *t161;
    int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned char t178;
    char *t179;
    char *t180;
    char *t181;
    char *t182;

LAB0:    xsi_set_current_line(35, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB7;

LAB8:    xsi_set_current_line(43, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t2 = t1;
    memset(t2, (unsigned char)4, 32U);
    t5 = (t0 + 3880);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    t18 = (t12 + 56U);
    t20 = *((char **)t18);
    memcpy(t20, t1, 32U);
    xsi_driver_first_trans_fast_port(t5);

LAB3:    t1 = (t0 + 3736);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(36, ng0);
    t1 = (t0 + 1992U);
    t5 = *((char **)t1);
    t6 = (21 - 31);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t5 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 1992U);
    t12 = *((char **)t11);
    t13 = (21 - 31);
    t14 = (t13 * -1);
    t15 = (1U * t14);
    t16 = (0 + t15);
    t11 = (t12 + t16);
    t17 = *((unsigned char *)t11);
    t20 = ((IEEE_P_2592010699) + 4024);
    t18 = xsi_base_array_concat(t18, t19, t20, (char)99, t10, (char)99, t17, (char)101);
    t21 = (t0 + 1992U);
    t22 = *((char **)t21);
    t23 = (21 - 31);
    t24 = (t23 * -1);
    t25 = (1U * t24);
    t26 = (0 + t25);
    t21 = (t22 + t26);
    t27 = *((unsigned char *)t21);
    t30 = ((IEEE_P_2592010699) + 4024);
    t28 = xsi_base_array_concat(t28, t29, t30, (char)97, t18, t19, (char)99, t27, (char)101);
    t31 = (t0 + 1992U);
    t32 = *((char **)t31);
    t33 = (21 - 31);
    t34 = (t33 * -1);
    t35 = (1U * t34);
    t36 = (0 + t35);
    t31 = (t32 + t36);
    t37 = *((unsigned char *)t31);
    t40 = ((IEEE_P_2592010699) + 4024);
    t38 = xsi_base_array_concat(t38, t39, t40, (char)97, t28, t29, (char)99, t37, (char)101);
    t41 = (t0 + 1992U);
    t42 = *((char **)t41);
    t43 = (21 - 31);
    t44 = (t43 * -1);
    t45 = (1U * t44);
    t46 = (0 + t45);
    t41 = (t42 + t46);
    t47 = *((unsigned char *)t41);
    t50 = ((IEEE_P_2592010699) + 4024);
    t48 = xsi_base_array_concat(t48, t49, t50, (char)97, t38, t39, (char)99, t47, (char)101);
    t51 = (t0 + 1992U);
    t52 = *((char **)t51);
    t53 = (21 - 31);
    t54 = (t53 * -1);
    t55 = (1U * t54);
    t56 = (0 + t55);
    t51 = (t52 + t56);
    t57 = *((unsigned char *)t51);
    t60 = ((IEEE_P_2592010699) + 4024);
    t58 = xsi_base_array_concat(t58, t59, t60, (char)97, t48, t49, (char)99, t57, (char)101);
    t61 = (t0 + 1992U);
    t62 = *((char **)t61);
    t63 = (21 - 31);
    t64 = (t63 * -1);
    t65 = (1U * t64);
    t66 = (0 + t65);
    t61 = (t62 + t66);
    t67 = *((unsigned char *)t61);
    t70 = ((IEEE_P_2592010699) + 4024);
    t68 = xsi_base_array_concat(t68, t69, t70, (char)97, t58, t59, (char)99, t67, (char)101);
    t71 = (t0 + 1992U);
    t72 = *((char **)t71);
    t73 = (21 - 31);
    t74 = (t73 * -1);
    t75 = (1U * t74);
    t76 = (0 + t75);
    t71 = (t72 + t76);
    t77 = *((unsigned char *)t71);
    t80 = ((IEEE_P_2592010699) + 4024);
    t78 = xsi_base_array_concat(t78, t79, t80, (char)97, t68, t69, (char)99, t77, (char)101);
    t81 = (t0 + 1992U);
    t82 = *((char **)t81);
    t83 = (21 - 31);
    t84 = (t83 * -1);
    t85 = (1U * t84);
    t86 = (0 + t85);
    t81 = (t82 + t86);
    t87 = *((unsigned char *)t81);
    t90 = ((IEEE_P_2592010699) + 4024);
    t88 = xsi_base_array_concat(t88, t89, t90, (char)97, t78, t79, (char)99, t87, (char)101);
    t91 = (t0 + 1992U);
    t92 = *((char **)t91);
    t93 = (21 - 31);
    t94 = (t93 * -1);
    t95 = (1U * t94);
    t96 = (0 + t95);
    t91 = (t92 + t96);
    t97 = *((unsigned char *)t91);
    t100 = ((IEEE_P_2592010699) + 4024);
    t98 = xsi_base_array_concat(t98, t99, t100, (char)97, t88, t89, (char)99, t97, (char)101);
    t101 = (t0 + 1992U);
    t102 = *((char **)t101);
    t103 = (31 - 21);
    t104 = (t103 * 1U);
    t105 = (0 + t104);
    t101 = (t102 + t105);
    t108 = ((IEEE_P_2592010699) + 4024);
    t110 = (t109 + 0U);
    t111 = (t110 + 0U);
    *((int *)t111) = 21;
    t111 = (t110 + 4U);
    *((int *)t111) = 0;
    t111 = (t110 + 8U);
    *((int *)t111) = -1;
    t112 = (0 - 21);
    t113 = (t112 * -1);
    t113 = (t113 + 1);
    t111 = (t110 + 12U);
    *((unsigned int *)t111) = t113;
    t106 = xsi_base_array_concat(t106, t107, t108, (char)97, t98, t99, (char)97, t101, t109, (char)101);
    t113 = (1U + 1U);
    t114 = (t113 + 1U);
    t115 = (t114 + 1U);
    t116 = (t115 + 1U);
    t117 = (t116 + 1U);
    t118 = (t117 + 1U);
    t119 = (t118 + 1U);
    t120 = (t119 + 1U);
    t121 = (t120 + 1U);
    t122 = (t121 + 22U);
    t123 = (32U != t122);
    if (t123 == 1)
        goto LAB5;

LAB6:    t111 = (t0 + 3880);
    t124 = (t111 + 56U);
    t125 = *((char **)t124);
    t126 = (t125 + 56U);
    t127 = *((char **)t126);
    memcpy(t127, t106, 32U);
    xsi_driver_first_trans_fast_port(t111);
    goto LAB3;

LAB5:    xsi_size_not_matching(32U, t122, 0);
    goto LAB6;

LAB7:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 1992U);
    t5 = *((char **)t1);
    t6 = (16 - 31);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t5 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 1992U);
    t12 = *((char **)t11);
    t13 = (16 - 31);
    t14 = (t13 * -1);
    t15 = (1U * t14);
    t16 = (0 + t15);
    t11 = (t12 + t16);
    t17 = *((unsigned char *)t11);
    t20 = ((IEEE_P_2592010699) + 4024);
    t18 = xsi_base_array_concat(t18, t19, t20, (char)99, t10, (char)99, t17, (char)101);
    t21 = (t0 + 1992U);
    t22 = *((char **)t21);
    t23 = (16 - 31);
    t24 = (t23 * -1);
    t25 = (1U * t24);
    t26 = (0 + t25);
    t21 = (t22 + t26);
    t27 = *((unsigned char *)t21);
    t30 = ((IEEE_P_2592010699) + 4024);
    t28 = xsi_base_array_concat(t28, t29, t30, (char)97, t18, t19, (char)99, t27, (char)101);
    t31 = (t0 + 1992U);
    t32 = *((char **)t31);
    t33 = (16 - 31);
    t34 = (t33 * -1);
    t35 = (1U * t34);
    t36 = (0 + t35);
    t31 = (t32 + t36);
    t37 = *((unsigned char *)t31);
    t40 = ((IEEE_P_2592010699) + 4024);
    t38 = xsi_base_array_concat(t38, t39, t40, (char)97, t28, t29, (char)99, t37, (char)101);
    t41 = (t0 + 1992U);
    t42 = *((char **)t41);
    t43 = (16 - 31);
    t44 = (t43 * -1);
    t45 = (1U * t44);
    t46 = (0 + t45);
    t41 = (t42 + t46);
    t47 = *((unsigned char *)t41);
    t50 = ((IEEE_P_2592010699) + 4024);
    t48 = xsi_base_array_concat(t48, t49, t50, (char)97, t38, t39, (char)99, t47, (char)101);
    t51 = (t0 + 1992U);
    t52 = *((char **)t51);
    t53 = (16 - 31);
    t54 = (t53 * -1);
    t55 = (1U * t54);
    t56 = (0 + t55);
    t51 = (t52 + t56);
    t57 = *((unsigned char *)t51);
    t60 = ((IEEE_P_2592010699) + 4024);
    t58 = xsi_base_array_concat(t58, t59, t60, (char)97, t48, t49, (char)99, t57, (char)101);
    t61 = (t0 + 1992U);
    t62 = *((char **)t61);
    t63 = (16 - 31);
    t64 = (t63 * -1);
    t65 = (1U * t64);
    t66 = (0 + t65);
    t61 = (t62 + t66);
    t67 = *((unsigned char *)t61);
    t70 = ((IEEE_P_2592010699) + 4024);
    t68 = xsi_base_array_concat(t68, t69, t70, (char)97, t58, t59, (char)99, t67, (char)101);
    t71 = (t0 + 1992U);
    t72 = *((char **)t71);
    t73 = (16 - 31);
    t74 = (t73 * -1);
    t75 = (1U * t74);
    t76 = (0 + t75);
    t71 = (t72 + t76);
    t77 = *((unsigned char *)t71);
    t80 = ((IEEE_P_2592010699) + 4024);
    t78 = xsi_base_array_concat(t78, t79, t80, (char)97, t68, t69, (char)99, t77, (char)101);
    t81 = (t0 + 1992U);
    t82 = *((char **)t81);
    t83 = (16 - 31);
    t84 = (t83 * -1);
    t85 = (1U * t84);
    t86 = (0 + t85);
    t81 = (t82 + t86);
    t87 = *((unsigned char *)t81);
    t90 = ((IEEE_P_2592010699) + 4024);
    t88 = xsi_base_array_concat(t88, t89, t90, (char)97, t78, t79, (char)99, t87, (char)101);
    t91 = (t0 + 1992U);
    t92 = *((char **)t91);
    t93 = (16 - 31);
    t94 = (t93 * -1);
    t95 = (1U * t94);
    t96 = (0 + t95);
    t91 = (t92 + t96);
    t97 = *((unsigned char *)t91);
    t100 = ((IEEE_P_2592010699) + 4024);
    t98 = xsi_base_array_concat(t98, t99, t100, (char)97, t88, t89, (char)99, t97, (char)101);
    t101 = (t0 + 1992U);
    t102 = *((char **)t101);
    t112 = (16 - 31);
    t103 = (t112 * -1);
    t104 = (1U * t103);
    t105 = (0 + t104);
    t101 = (t102 + t105);
    t123 = *((unsigned char *)t101);
    t108 = ((IEEE_P_2592010699) + 4024);
    t106 = xsi_base_array_concat(t106, t107, t108, (char)97, t98, t99, (char)99, t123, (char)101);
    t110 = (t0 + 1992U);
    t111 = *((char **)t110);
    t128 = (16 - 31);
    t113 = (t128 * -1);
    t114 = (1U * t113);
    t115 = (0 + t114);
    t110 = (t111 + t115);
    t129 = *((unsigned char *)t110);
    t125 = ((IEEE_P_2592010699) + 4024);
    t124 = xsi_base_array_concat(t124, t109, t125, (char)97, t106, t107, (char)99, t129, (char)101);
    t126 = (t0 + 1992U);
    t127 = *((char **)t126);
    t130 = (16 - 31);
    t116 = (t130 * -1);
    t117 = (1U * t116);
    t118 = (0 + t117);
    t126 = (t127 + t118);
    t131 = *((unsigned char *)t126);
    t134 = ((IEEE_P_2592010699) + 4024);
    t132 = xsi_base_array_concat(t132, t133, t134, (char)97, t124, t109, (char)99, t131, (char)101);
    t135 = (t0 + 1992U);
    t136 = *((char **)t135);
    t137 = (16 - 31);
    t119 = (t137 * -1);
    t120 = (1U * t119);
    t121 = (0 + t120);
    t135 = (t136 + t121);
    t138 = *((unsigned char *)t135);
    t141 = ((IEEE_P_2592010699) + 4024);
    t139 = xsi_base_array_concat(t139, t140, t141, (char)97, t132, t133, (char)99, t138, (char)101);
    t142 = (t0 + 1992U);
    t143 = *((char **)t142);
    t144 = (16 - 31);
    t122 = (t144 * -1);
    t145 = (1U * t122);
    t146 = (0 + t145);
    t142 = (t143 + t146);
    t147 = *((unsigned char *)t142);
    t150 = ((IEEE_P_2592010699) + 4024);
    t148 = xsi_base_array_concat(t148, t149, t150, (char)97, t139, t140, (char)99, t147, (char)101);
    t151 = (t0 + 1992U);
    t152 = *((char **)t151);
    t153 = (31 - 16);
    t154 = (t153 * 1U);
    t155 = (0 + t154);
    t151 = (t152 + t155);
    t158 = ((IEEE_P_2592010699) + 4024);
    t160 = (t159 + 0U);
    t161 = (t160 + 0U);
    *((int *)t161) = 16;
    t161 = (t160 + 4U);
    *((int *)t161) = 0;
    t161 = (t160 + 8U);
    *((int *)t161) = -1;
    t162 = (0 - 16);
    t163 = (t162 * -1);
    t163 = (t163 + 1);
    t161 = (t160 + 12U);
    *((unsigned int *)t161) = t163;
    t156 = xsi_base_array_concat(t156, t157, t158, (char)97, t148, t149, (char)97, t151, t159, (char)101);
    t163 = (1U + 1U);
    t164 = (t163 + 1U);
    t165 = (t164 + 1U);
    t166 = (t165 + 1U);
    t167 = (t166 + 1U);
    t168 = (t167 + 1U);
    t169 = (t168 + 1U);
    t170 = (t169 + 1U);
    t171 = (t170 + 1U);
    t172 = (t171 + 1U);
    t173 = (t172 + 1U);
    t174 = (t173 + 1U);
    t175 = (t174 + 1U);
    t176 = (t175 + 1U);
    t177 = (t176 + 17U);
    t178 = (32U != t177);
    if (t178 == 1)
        goto LAB9;

LAB10:    t161 = (t0 + 3880);
    t179 = (t161 + 56U);
    t180 = *((char **)t179);
    t181 = (t180 + 56U);
    t182 = *((char **)t181);
    memcpy(t182, t156, 32U);
    xsi_driver_first_trans_fast_port(t161);
    goto LAB3;

LAB9:    xsi_size_not_matching(32U, t177, 0);
    goto LAB10;

}


extern void work_a_0380725995_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0380725995_3212880686_p_0,(void *)work_a_0380725995_3212880686_p_1};
	xsi_register_didat("work_a_0380725995_3212880686", "isim/testbenchI2C_isim_beh.exe.sim/work/a_0380725995_3212880686.didat");
	xsi_register_executes(pe);
}
