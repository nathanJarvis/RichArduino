/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_2592010699;
char *STD_STANDARD;
char *IEEE_P_3620187407;
char *IEEE_P_3499444699;
char *IEEE_P_1242562249;
char *UNISIM_P_0947159679;
char *STD_TEXTIO;
char *IEEE_P_0774719531;
char *IEEE_P_2717149903;
char *IEEE_P_1367372525;
char *UNISIM_P_3222816464;
char *VL_P_2533777724;
char *IEEE_P_3564397177;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000000889817263_3369814199_init();
    ieee_p_2592010699_init();
    ieee_p_3499444699_init();
    ieee_p_3620187407_init();
    ieee_p_1242562249_init();
    unisim_p_0947159679_init();
    ieee_p_0774719531_init();
    std_textio_init();
    ieee_p_2717149903_init();
    ieee_p_1367372525_init();
    unisim_p_3222816464_init();
    unisim_a_0780662263_2014779070_init();
    unisim_a_0964940489_2930107152_init();
    unisim_a_3604006244_1532504268_init();
    unisim_a_1490675510_1976025627_init();
    work_a_0852845514_0912031422_init();
    work_a_1991350011_3212880686_init();
    work_a_0361700727_3212880686_init();
    work_a_0997799409_3212880686_init();
    work_a_0832606739_3212880686_init();
    work_a_3603251467_3212880686_init();
    work_a_1111616105_3212880686_init();
    work_a_2316809253_3212880686_init();
    work_a_3229675882_3212880686_init();
    work_a_0380725995_3212880686_init();
    work_a_2851529566_3212880686_init();
    work_a_3222946569_3212880686_init();
    work_a_3487412247_0632001823_init();
    work_a_2835375152_3212880686_init();
    work_a_2444083905_3212880686_init();
    vl_p_2533777724_init();
    unisim_a_0760032028_2930107152_init();
    unisim_a_0920623294_1532504268_init();
    work_a_4183106191_0912031422_init();
    ieee_p_3564397177_init();
    xilinxcorelib_a_1242084086_2959432447_init();
    xilinxcorelib_a_0219890701_2959432447_init();
    xilinxcorelib_a_4286692035_1709443946_init();
    xilinxcorelib_a_2470264820_0543512595_init();
    xilinxcorelib_a_2567559136_3212880686_init();
    work_a_0021254903_1750795776_init();
    xilinxcorelib_a_0839439422_2959432447_init();
    xilinxcorelib_a_3110244288_1709443946_init();
    xilinxcorelib_a_2425841510_0543512595_init();
    xilinxcorelib_a_3817353611_3212880686_init();
    work_a_2422000210_3164410831_init();
    unisim_a_3321449454_0621957688_init();
    unisim_a_1478392591_3979135294_init();
    work_a_0519650324_0632001823_init();
    work_a_2438414969_3665547200_init();
    work_a_3140149623_0632001823_init();
    work_a_1420560235_3212880686_init();
    work_a_1335952598_0632001823_init();
    work_a_2491911633_2372691052_init();


    xsi_register_tops("work_a_2491911633_2372691052");

    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_3620187407 = xsi_get_engine_memory("ieee_p_3620187407");
    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    UNISIM_P_0947159679 = xsi_get_engine_memory("unisim_p_0947159679");
    STD_TEXTIO = xsi_get_engine_memory("std_textio");
    IEEE_P_0774719531 = xsi_get_engine_memory("ieee_p_0774719531");
    IEEE_P_2717149903 = xsi_get_engine_memory("ieee_p_2717149903");
    IEEE_P_1367372525 = xsi_get_engine_memory("ieee_p_1367372525");
    UNISIM_P_3222816464 = xsi_get_engine_memory("unisim_p_3222816464");
    VL_P_2533777724 = xsi_get_engine_memory("vl_p_2533777724");
    IEEE_P_3564397177 = xsi_get_engine_memory("ieee_p_3564397177");

    return xsi_run_simulation(argc, argv);

}
